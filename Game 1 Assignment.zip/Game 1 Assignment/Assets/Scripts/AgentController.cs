using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class AgentController : MonoBehaviour
{
    [SerializeField] private AgentState moveState;
    [SerializeField] private AgentState searchState;
    [SerializeField] private AgentState attackState;
    [SerializeField] private AgentState defendState;

    [SerializeField] private GameObject shield;

    [SerializeField] private float fireVelocity;

    [SerializeField] private GameObject bullet;

    [SerializeField] private GameObject gun;

    [SerializeField] private NavMeshAgent agent;

    [SerializeField] private Transform flagPosition;

    [SerializeField] private Transform playerPosition;

    [SerializeField] private PlayerController playerController;

    // Start is called before the first frame update
    void Start()
    {
        moveState.SetUp(this, agent, playerPosition, flagPosition, playerController, fireVelocity, bullet, gun, shield);
        searchState.SetUp(this, agent, playerPosition, flagPosition, playerController, fireVelocity, bullet, gun, shield);
        attackState.SetUp(this, agent, playerPosition, flagPosition, playerController, fireVelocity, bullet, gun, shield);
        defendState.SetUp(this, agent, playerPosition, flagPosition, playerController, fireVelocity, bullet, gun, shield);

        searchState.Do();
        moveState.Do();
    }

    // Update is called once per frame
    void Update()
    {
        searchState.Do();

        if(attackState.IsPlayerVisible)
        {
            if(attackState.StillHaveBullets)
            {
                attackState.Do();
            }
            else
            {
                defendState.Do();
            }
        }

 
    }
}
