using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UIElements;
public abstract class AgentState : MonoBehaviour
{
    public bool IsCompleted{get; protected set; }
    public bool IsPlayerVisible { get; protected set; }

    public bool StillHaveBullets { get; protected set; }

    protected AgentController agentController;

    protected NavMeshAgent agent;

    protected Transform flagPosition;

    protected Transform playerPosition;

    protected PlayerController playerController;

    protected float fireVelocity;

    protected GameObject bullet;

    protected GameObject gun;

    protected GameObject shield;

    float startTime;

    float time => Time.time - startTime;
    

    public virtual void Enter(){ }
    public virtual void Do(){ }
    public virtual void FixedDo(){ }
    public virtual void Exit() { }
    

    public void SetUp(AgentController agentController, NavMeshAgent agent, Transform playerPos, Transform flagPos, 
        PlayerController playerController, float fireVelocity, GameObject bullet, GameObject gun, GameObject shield)
    {
        this.agentController = agentController;
        this.playerController = playerController;
        this.agent = agent;
        playerPosition = playerPos;
        flagPosition = flagPos;
        this.fireVelocity = fireVelocity;
        this.bullet = bullet;
        this.gun = gun;
        this.shield = shield;
    }

    protected Vector3 GetPlayerDirection()
    {
        Vector3 direction = playerController.transform.position - agentController.transform.position;
        return direction.normalized;
    }

    protected void Shoot()
    {
        Vector3 gunPosition = gun.transform.position;
        Vector3 dir = (playerController.transform.position - gunPosition).normalized;

        GameObject bulletInstance = Instantiate(bullet, gunPosition, Quaternion.identity);
        Rigidbody bulletRb = bulletInstance.GetComponent<Rigidbody>();
        bulletRb.useGravity = false;

        bulletRb.AddForce(dir * fireVelocity);
    }
}
