using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgentMoveState : AgentState
{
    public override void Enter()
    {

    }

    public override void Do()
    {
        if(!IsPlayerVisible)
        {
            agent.destination = flagPosition.position;
        } else if(IsPlayerVisible)
        {
            agent.destination = playerPosition.position;
        }
    }

    public override void Exit()
    {

    }
}
