using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgentAttackState : AgentState
{
    private int numBullets = 2;
    public override void Do()
    {
        if(numBullets == 0)
        {
            return;
        }
        Shoot();
    }
}
