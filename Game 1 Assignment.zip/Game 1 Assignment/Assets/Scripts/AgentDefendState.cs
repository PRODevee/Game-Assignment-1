using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgentDefendState : AgentState
{
    public override void Do()
    {
        shield.SetActive(true);
        StopAllCoroutines();
        StartCoroutine(ShieldTime());
        shield.SetActive(false);
    }
    IEnumerator ShieldTime()
    {
        yield return new WaitForSeconds(2.5f);
    }
}
