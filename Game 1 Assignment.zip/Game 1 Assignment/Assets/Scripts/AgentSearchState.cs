using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgentSearchState : AgentState
{
    public override void Do()
    {
        if(Physics.Raycast(agentController.transform.position, GetPlayerDirection(), 70))
        {
            IsPlayerVisible = true;
        }
    }
}
